package Processing;

import processing.core.PApplet;

public interface IProcessingApp {

    public void setup(PApplet p);

    public void draw(PApplet p, float deltaT);

    public void mousePressed(PApplet p);

    public void keyPressed(PApplet P);
}
